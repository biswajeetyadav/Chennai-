export interface Employee {
    id: any,
    name: string,
    email: string,
    mobile: number,
    department: string

}
