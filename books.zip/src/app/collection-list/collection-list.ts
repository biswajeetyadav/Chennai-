import { Component, EventEmitter, Input, Output, output } from '@angular/core';
import { Book } from '../book';
@Component({
  selector: 'app-collection-list',
  imports: [],
  templateUrl: './collection-list.html',
  styleUrl: './collection-list.css',
})
export class CollectionList {
  @Input() books: ReadonlyArray<Book> = [];
  @Output() remove= new EventEmitter<string>();

}
