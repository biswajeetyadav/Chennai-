import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Book } from '../book';

@Component({
  selector: 'app-bool-list',
  imports: [],
  templateUrl: './bool-list.html',
  styleUrl: './bool-list.css',
})
export class BoolList {
  @Input() books: ReadonlyArray<Book> = [];
  @Output() add =new EventEmitter<string>();
}
