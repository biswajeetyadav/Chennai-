import { Component, inject, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Store } from '@ngrx/store';
import { selectBookCollectionState, selectBooks } from './state/books.selectors';
import { BookApiActions, BooksActions } from './state/books.actions';
import { BoolList } from './bool-list/bool-list';
import { CollectionList } from './collection-list/collection-list';
import { BooksService } from './books-service';


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CollectionList, BoolList],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('books');
  protected readonly store = inject(Store);
  private readonly bookService  = inject(BooksService)
  private books = this.store.selectSignal(selectBooks);
  protected bookCollection = this.store.selectSignal(selectBookCollectionState);

  protected onAdd(bookId: string) {
    this.store.dispatch(BooksActions.addBook({ bookId }));
  }

  protected onRemove(bookId: string) {
    this.store.dispatch(BooksActions.removeBook({ bookId }));
  }

  ngOnInit() {
    this.bookService
      .getBooks()
      .subscribe((books) =>
        this.store.dispatch(BookApiActions.retrievedBookList({ books }))
      );
  }
}





