import {
  MatFormFieldModule
} from "./chunk-NJRJT6CP.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-V67JMF2T.js";
import "./chunk-552244FA.js";
import "./chunk-LDLYPMAW.js";
import "./chunk-2ZJV4JUS.js";
import "./chunk-PJAM64CS.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-OKAY53VZ.js";
import "./chunk-4RCHZ5NK.js";
import "./chunk-NBOSJYBY.js";
import "./chunk-U7M7YWMT.js";
import "./chunk-FDRZLPZY.js";
import "./chunk-4FRP4S3T.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
