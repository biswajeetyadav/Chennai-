import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggle } from '@angular/material/button-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { AddEmployee } from '../add-employee/add-employee';

@Component({
  selector: 'app-employee',
  imports: [MatCardModule, MatButtonModule, MatDialogModule],
  templateUrl: './employee.html',
  styleUrl: './employee.css',
})
export class Employee {

  constructor(private dialog:MatDialog){

  }

  addemployee(){
    this.dialog.open(AddEmployee, {
      width:'50%',
      exitAnimationDuration:'1000ms',
      enterAnimationDuration:'1000ms'
    })

  }
}
