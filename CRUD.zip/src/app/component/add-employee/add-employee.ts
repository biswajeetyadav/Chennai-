import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { Validators } from '@angular/forms';
import { MatFormField } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatAnchor } from "@angular/material/button";

@Component({
  selector: 'app-add-employee',
  imports: [MatCardModule, ReactiveFormsModule, MatFormField, MatInputModule, MatDatepickerModule, MatSelectModule,
    MatIconModule, MatAnchor],
  templateUrl: './add-employee.html',
  providers: [provideNativeDateAdapter()],
  styleUrl: './add-employee.css',
})
export class AddEmployee {

  title='Add Employee'
  empForm=new FormGroup({
    id: new FormControl(0),
    name: new FormControl('', Validators.required),
    doj:new FormControl(new Date, Validators.required),
    role:new FormControl('',Validators.required),
    salary: new FormControl(0, Validators.required)
  })

  SaveEmployee(){
    if(this.empForm.valid){
      console.log(this.empForm.value)
    }
  }

//   empForm = new FormGroup({
//     id: new FormControl(0),
//     name: new FormControl('', Validators.required),
//     doj: new FormControl(new Date(), Validators.required),
//     role: new FormControl('', Validators.required),
//     salary: new FormControl(0, Validators.required)
//   })

//   SaveEmployee() {
//     if (this.empForm.valid) {
//       console.log(this.empForm.value)
//       }
// }
}
