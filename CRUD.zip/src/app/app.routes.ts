import { Routes } from '@angular/router';
import { Employee } from './component/employee/employee';
import { AddEmployee } from './component/add-employee/add-employee';

export const routes: Routes = [
    {
        path:'employee', component:Employee
    }
];
