import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Auth } from '../service/auth';
import { Router, RouterModule } from '@angular/router';
// import { HttpClient } from '@angular/common/http';
// import { OnInit } from '@angular/core';


@Component({
  selector: 'app-create',
  imports: [FormsModule, RouterModule, ReactiveFormsModule],
  templateUrl: './create.html',
  styleUrl: './create.css',
})
export class Create {
  createForm: FormGroup = new FormGroup({});
  message:string = "";

  constructor(private auth: Auth, private fb: FormBuilder, private router: Router){}

  ngOnInit(): void{
    this.createForm = this.fb.group({
      Description: new FormControl('')
    })
  }

  CreateItem(): void{
    const Description = this.createForm.get('Description')?.value;
    if(Description.trim().legnth == 0){
      alert("can't put empty todo")
    }
    else{
      this.auth.addItem(this.createForm.value).subscribe(res=>{
        this.message = "Successfully created";
        setTimeout(()=>{
          this.router.navigate(['/Dashboard'])
        }, 1000)
      })
    }
  }

}
