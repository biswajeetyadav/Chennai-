import { Routes } from '@angular/router';
import { Dashboard } from './dashboard/dashboard';
import { Create } from './create/create';
import { Read } from './read/read';
import { Update } from './update/update';


export const routes: Routes = [
    {path:'', redirectTo:'Dashboard', pathMatch:'full'},
    {path:'Dashboard', component:Dashboard},
    {path:'create', component:Create},
    {path:'update', component:Update},
    {path:'update/:id',component:Update }
];
