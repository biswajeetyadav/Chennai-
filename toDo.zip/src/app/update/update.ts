import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { Auth } from '../service/auth';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Item } from '../item';
import { OnInit } from '@angular/core';



@Component({
  selector: 'app-update',
  imports: [RouterModule, FormsModule, ReactiveFormsModule],
  templateUrl: './update.html',
  styleUrl: './update.css',
})
export class Update implements OnInit{
  // private item: Item  =
  id:any;
  itemdetail:any;
  updateform:FormGroup = new FormGroup({})
  constructor(private auth: Auth, private fb: FormBuilder, private router: Router, private route:ActivatedRoute){}

  ngOnInit(): void {
    this.route.params.subscribe(res => {
      this.id= res['id'];
      console.log(this.id);
    })

    if(this.id != ''){
      this.auth.getItemById(this.id).toPromise()
      .then(res => {
        this.itemdetail = res;
        console.log(this.itemdetail);
        console.log("res is working")
        this.updateform  = this.fb.group({
          'Description' : new FormControl(this.itemdetail.Description)
        })
      })
    }
  }

  message:any;
  updatingItem():void{
    this.auth.updateItem(this.id, this.updateform.value).subscribe(res =>{
      this.message = "updated successfully";
      setTimeout(()=>{
        this.router.navigate(['/Dashboard'])
      }, 1000)
    });

  }


}
