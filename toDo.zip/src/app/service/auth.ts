import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Item } from '../item';

@Injectable({
  providedIn: 'root',
})
export class Auth {

  private baseUrl:string = "http://localhost:3000/Todo"

  constructor(private http: HttpClient){}

  getItem(): Observable<Item[]>{
    return this.http.get<Item[]>(this.baseUrl)
  }

  getItemById(id:string): Observable<Item>{
    return this.http.get<Item>(this.baseUrl+"/"+id);
  }

  addItem(obj:Item){
      return this.http.post(this.baseUrl+"/", obj)
  }

  updateItem(id:string, obj:Item){
    return this.http.put(this.baseUrl +'/'+id, obj)
  }

}
