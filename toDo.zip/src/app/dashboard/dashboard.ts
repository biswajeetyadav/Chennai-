import { Component } from '@angular/core';
import { Item } from '../item';
import { Auth } from '../service/auth';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';




@Component({
  selector: 'app-dashboard',
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard {
  constructor(private auth:Auth,private router:ActivatedRoute){}
  allItems: Item[] = [];
  message:string = ""

  ngOnInit():void{
    this.auth.getItem().subscribe(res => {
      this.allItems = res;
      console.log(this.allItems);
    })

  }



}
