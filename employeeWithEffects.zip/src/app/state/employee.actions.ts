import { createAction, props } from "@ngrx/store";
import { Iemployee } from "../iemployee";


export const CreateEmployee = createAction('[Create] Create Employee', props<{employee:Iemployee}>())