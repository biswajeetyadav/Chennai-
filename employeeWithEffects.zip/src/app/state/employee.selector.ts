import { createSelector } from "@ngrx/store";
import { createFeatureSelector } from "@ngrx/store";
import { employeeState } from "./employee.reduce";

export const selectEmployeeState = createFeatureSelector<employeeState>('employee');

export const selectAllEmployee = createSelector(
    selectEmployeeState,
    (state)=> state.employee
)