import { createReducer, on } from "@ngrx/store";
import { Iemployee } from "../iemployee";
import { CreateEmployee } from "./employee.actions";

export interface employeeState {
    employee: Iemployee[];
}

export const initialState: employeeState ={
    employee: []
}

export const employeeReducer = createReducer(
    initialState,
    on(CreateEmployee, (state, {employee})=>({
        employee: [...state.employee, employee]
    }))
)