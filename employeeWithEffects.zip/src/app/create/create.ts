import { AsyncPipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { employeeReducer } from '../state/employee.reduce';
import { Iemployee } from '../iemployee';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-create',
  imports: [FormsModule, ReactiveFormsModule, AsyncPipe],
  templateUrl: './create.html',
  styleUrl: './create.css',
})
export class Create {

  constructor(private store: Store, private fb: FormBuilder ){}

  Employee&! : Observable<{Iemployee[]}>

}
