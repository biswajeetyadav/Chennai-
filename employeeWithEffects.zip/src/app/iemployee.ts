export interface Iemployee {
    name:string,
    dept:string
}
